#include <iostream>

class Shape
{
public:
	virtual Shape* Clone() {  return 0; }
};

template<typename T> class Clonable : public Shape
{
public:
	virtual Shape* Clone() override { return 0; }
};

class Rect : public Clonable<Rect>
{
};

int main()
{
	Shape* p = new Rect;
	p->Clone();
}