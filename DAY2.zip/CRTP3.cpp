#include <iostream>
#include <vector>

class NotImplemented {};

class Shape
{
	int color;
public:
	virtual ~Shape() {}

	void SetColor(int c) { color = c; }
	int  GetColor() const { return color; }


public:
	virtual void Draw() final
	{
		std::cout << "Mutex lock" << std::endl;
		DrawImp();
		std::cout << "Mutex unlock" << std::endl;
	}
protected:
	virtual void DrawImp() = 0;

public:
	virtual Shape* Clone() const
	{
		throw NotImplemented();
	}
	virtual int GetArea() const { return -1; }
};

class Clonable : public Shape
{
public:
	virtual Clonable* Clone() const override
	{
		Shape* p = new Clonable(*this);
		return p;
	}
};
//-------------------------------------------
class Rect : public Clonable
{
public:
	virtual void DrawImp() override { std::cout << "Draw Rect" << std::endl; }
};


class Circle : public Clonable
{
public:
	virtual void DrawImp() override { std::cout << "Draw Circle" << std::endl; }
};

int main()
{
	Shape* s1 = new Rect;
	Shape* s2 = new Circle;

	Shape* s3 = s1->Clone();
	Shape* s4 = s2->Clone();


}

