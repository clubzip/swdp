// upcasting3.cpp
class Animal 
{
public: 
	int age;
};
class Cat : public Animal 
{
};
class Dog : public Animal
{
public:
	int color;
};

void NewYear(Dog* p)  
{
	++(p->age); // ���ذ� �Ǹ� ���̰� ����.
	
}
int main()
{
	Dog    d; NewYear(&d);
	Cat    c; NewYear(&c);
}












